#include "types.h"

BOOLEAN LoadSTCIFileToImage( HIMAGE hImage, UINT16 fContents );

BOOLEAN IsSTCIETRLEFile( CHAR8 * ImageFile );
