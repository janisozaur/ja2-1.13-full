#ifndef __VOBJECT_PRIVATE_
#define __VOBJECT_PRIVATE_

#endif