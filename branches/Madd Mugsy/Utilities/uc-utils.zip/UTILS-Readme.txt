1. Extract the utils.exe to your ja2 folder for all programs to work properly.


2. A small list of what programs you'll find in this pack and what they'll do:

- JA2_BETA.EXE  The German Ja2.exe, which holds the beta editor.
- JA2BETA.BAT  use this to start up the Ja2 Beta editor. For a guide of the
  editor, check out Ja2-editor-tutorial.pdf

- JA2Desktop.exe -- Batman's GUI multifunction editor.  Check out the
  exstensive help-function if you are new to the program.
- /Files  Files related to Batman's Ja2 desktop program.

- JA2PATCH.EXE -- Use this to apply the weapon/item info you just changed,
  to the exe. It's DOS based, so enter dos-mode (start -> run -> "cmd")
  to specify the ja2 exe you want patched. E.g.: ja2patch Ja2_UC.exe ;)

- JA2SME.EXE -- JA2 Stragegic Map editor. Use it to set sector descriptions,
  travel times, number of enemies and loadscreens.

- JA2WEDIT.EXE -- JA2 Weapon Editor. Use it to extract weapon data from your
  exe. This is also DOS based.
  Use Ja2 desktop to edit the text file (myweapons.txt) you extracted.

- UNSLF.EXE -- Dos-based tool for extracting .SLF files. The predecessor of
  Slf-explore by Bimbo, which is Windows-based.

- /JA2Tile Set Editor -- JA2 Tile Set Editor.
- /JA2EDT -- Tool for editing .EDT files. Allows you to edit the emails and
  text balloons.

- /DATA/BinaryData/PROEDIT.EXE -- JA2 NPC properties editor
- /DATA/BinaryData/UBPROEDIT.EXE -- JA2 UB NPC properties editor


3. Complete paclist:


DATA\BinaryData\*
DATA\EDITOR\*
DATA\GERMAN.SLF
DATA\UNSLF.EXE
Files\Batman.jpg
Files\BETA_M1.JPG
Files\BETA_M2.JPG
Files\BETA_MAP.HTM
Files\EndAction.BIN
Files\EXTRACTOR.HTM
Files\GUIEDIT.HTM
Files\GUI_O1.jpg
Files\GUI_W1.jpg
Files\GUI_W2.jpg
Files\Items.BIN
Files\JA2.BIN
Files\JA2SME.HTM
Files\JA2UB.BIN
Files\JA2wedit2.4.doc
Files\MercAction.BIN
Files\NPC.BIN
Files\NPCAction.jpg
Files\NPCFILE.BIN
Files\NPC_A1.jpg
Files\NPC_ACTION.HTM
Files\NPC_E1.jpg
Files\NPC_EDIT.HTM
Files\PROEDIT.HTM
Files\Quests.BIN
Files\RecAction.BIN
Files\SLF_E1.jpg
Files\Triggers.BIN
Files\UnSlf.txt
JA2EDT\CMDIALOG.VBX
JA2EDT\JA2EDT.EXE
JA2EDT\README.TXT
JA2EDT\TYPES.INI
JA2EDT\VBRUN300.DLL
JA2Tile Set Editor\CMDIALOG.VBX
JA2Tile Set Editor\JA2TSE_01.EXE
JA2Tile Set Editor\JA2TSE_11.EXE
JA2Tile Set Editor\README.TXT
JA2Tile Set Editor\VBRUN300.DLL
DOMAPS.BAT
JA2BETA.BAT
JA2Desktop.exe
JA2Desktop.ini
JA2PATCH.EXE
JA2SME.EXE
JA2WEDIT.EXE
JA2_BETA.EXE
SME_ADD.DAT
sme_basic.dat
SME_MAP.BMP
SME_MINE.DAT
sme_patch.dat
sme_upatch.dat
UNSLF.EXE
